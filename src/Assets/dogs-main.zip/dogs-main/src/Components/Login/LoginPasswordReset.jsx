import React from 'react'

const LoginPasswordReset = () => {
  return (
    <div>LoginPasswordReset</div>
  )
}

export default LoginPasswordReset