import React from 'react'

const NovoComponente = () => {
  return (
    <div>NovoComponente</div>
  )
}

export default NovoComponente