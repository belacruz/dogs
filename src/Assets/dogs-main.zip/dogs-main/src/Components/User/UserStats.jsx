import React from 'react'

const UserStats = () => {
  return (
    <div>UserStats</div>
  )
}

export default UserStats